import numpy as np
import math


class AckermannCar:

    def __init__(self, L=0.257):
        self.L = L 

    def kinematics(self, state, control, dt=1/12.):
        x, y, theta, beta = state
        

        v = min(max(control[0], -5.0), 5.0)
        steering_rate = min(max(control[1], -10), 10)

        xdot = v * math.cos(theta)
        ydot = v * math.sin(theta)
        thetadot = v/self.L * math.tan(beta)
        betadot = steering_rate

        x = x + dt * xdot
        y = y + dt * ydot
        theta = theta + dt * thetadot
        beta = beta + dt * betadot

        beta = min(max(beta, -0.4), 0.4)

        return [x,y,theta,beta]



if __name__=="__main__":
    tt02 = AckermannCar(L=0.257)
    
    state = [0,0,0,0.4]
    control = [1.0,0.0]
    j,i = 0,0

    while j != 1:
        i+=1
        state = tt02.kinematics(state, control)
        print(f"STATE AT TIME {i/12.}s: ", state)
        j = input("1 to stop")
