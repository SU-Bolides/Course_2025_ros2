#!/usr/bin/env python3

__author__ = "Nicolas HAMMJE"
__status__ = "In Developpement"

#%% IMPORTS
import numpy as np
import os
from pathlib import Path
from scipy import spatial
from math import cos, sin
from tf import transformations
from bicycle_model import create_model
import scipy
from acados_template import AcadosOcp, AcadosOcpSolver
from ackermann_car import AckermannCar

class AcadosMPC:
    def __init__(self, track):
        self.solver, self.model, self.N = self.create_ocp_solver(track)   

    def create_ocp_solver(self, track, Tf=2.0):

        model, constraint = create_model(track)

        ocp = AcadosOcp()
        ocp.model = model

        # Control bounds
        ocp.constraints.lbu = np.array([constraint.v_min, constraint.steering_rate_min])
        ocp.constraints.ubu = np.array([constraint.v_max, constraint.steering_rate_max])
        ocp.constraints.idxbu = np.array([0, 1])  # indexes of [v, steering rate]

        #State bounds
        ocp.constraints.lbx = np.array([constraint.delta_min]) #Maximum track deviation
        ocp.constraints.ubx = np.array([constraint.delta_max])
        ocp.constraints.idxbx = np.array([3])

        # dimensions
        nx = model.x.rows()
        nu = model.u.rows()
        ny = nx + nu
        ny_e = nx

        # 1) Discretization
        N = 12        # number of shooting intervals
        ocp.dims.N = N
        ocp.solver_options.tf = Tf
        ocp.solver_options.N_horizon = N

        # 2) Cost function
        Q = np.diag([ 1e-1, 1e-8, 1e-8, 5e-3 ])
        R = np.diag([1e-8, 5e-3])              # inputs
        Qe = np.diag([5.0,1.0,1e-8,2e-3])      # final state cost

        ocp.cost.cost_type = 'LINEAR_LS'
        ocp.cost.cost_type_e = 'LINEAR_LS'

        unscale = N/Tf

        ocp.cost.W = unscale * scipy.linalg.block_diag(Q, R)
        ocp.cost.W_e = Qe / unscale

        # Define Vx, Vu for the cost: y = Vx*x + Vu*u
        Vx = np.zeros((ny, nx))
        Vx[:nx, :nx] = np.eye(nx)
        ocp.cost.Vx = Vx 


        Vu = np.zeros((ny, nu))
        Vu[4, 0] = 1.0  # v
        Vu[5, 1] = 1.0  # steering rate
        ocp.cost.Vu = Vu

        # Terminal matrix Vx_e
        Vx_e = np.zeros((ny_e, nx))
        Vx_e[:nx, :nx] = np.eye(nx)
        ocp.cost.Vx_e = Vx_e

        ocp.constraints.x0 = np.array([0.0,0,0,0])
        
        # set intial references
        ocp.cost.yref = np.array([1.0, 0, 0, 0, 0, 0])
        ocp.cost.yref_e = np.array([0., 0, 0, 0])


        # set QP solver and integration
        ocp.solver_options.tf = Tf
        # ocp.solver_options.qp_solver = 'FULL_CONDENSING_QPOASES'
        ocp.solver_options.qp_solver = "PARTIAL_CONDENSING_HPIPM"
        ocp.solver_options.nlp_solver_type = "SQP"
        ocp.solver_options.hessian_approx = "GAUSS_NEWTON"
        ocp.solver_options.integrator_type = "ERK"
        ocp.solver_options.sim_method_num_stages = 4
        ocp.solver_options.sim_method_num_steps = 3
        # ocp.solver_options.nlp_solver_step_length = 0.05
        ocp.solver_options.nlp_solver_max_iter = 200
        ocp.solver_options.tol = 1e-4
        # ocp.solver_options.nlp_solver_tol_comp = 1e-1

        # create solver
        acados_solver = AcadosOcpSolver(ocp, json_file="acados_ocp.json")
        return acados_solver, model, N

    def simulate(self, state):

        #Set initial condition to the current state
        self.solver.set(0, "lbx", state)
        self.solver.set(0, "ubx", state)

        sref = 1.5
        s0 = state[0]

        print(s0 + sref)

        for j in range(self.N):
            yref = np.array([s0 + (sref - s0) * j / self.N, 0, 0, 0, 0, 0])
            self.solver.set(j, "yref", yref)
        yref_N = np.array([s0 + sref, 0, 0, 0])
        self.solver.set(self.N, "yref", yref_N)

        status = self.solver.solve()
        if status != 0:
            print("acados returned status {}".format(status))
            if not status == 2:
                return None, None

        u0 = self.solver.get(0, "u")
        x0 = self.solver.get(1, "x")
        print("final state ",self.solver.get(self.N, "x"))

        return u0, x0

        


class TrackUtils:

    def __init__(self, filename):
        self.filename = filename
        self.getTrack()

    def getTrack(self):
        track_file = os.path.join(str(Path(__file__).parent), self.filename)
        # array=np.loadtxt(track_file, delimiter=",")
        array=np.loadtxt(track_file)
        self.sref=array[:,0]
        self.xref=array[:,1]
        self.yref=array[:,2]
        self.psiref=array[:,3]
        self.kapparef=array[:,4]

        self.pos_refs = spatial.KDTree(np.column_stack((self.xref, self.yref)))

    def getClosest(self, x,y):
        
        dist, index = self.pos_refs.query([x,y])
        s = self.sref[index]
        psi = self.psiref[index]
        x_ref = self.xref[index]
        y_ref = self.yref[index]

        lateral_offset = (x - x_ref)*(-sin(psi)) + (y - y_ref) * cos(psi)

        return s, lateral_offset, psi, x_ref, y_ref


class MPC_Controller:
    '''
    This class implements an MPC controller
    '''
    def __init__(self, track="su_bigmap_splined.txt"):      
        # We need the spline representation of the track, the current position of the car, and finally a topic where we can send the control inputs u to (in this case, cmd_vel)
        self.WAYPOINTS_PATH = track
        self.utils = TrackUtils(self.WAYPOINTS_PATH)

        self.acados_mpc = AcadosMPC(self.WAYPOINTS_PATH)

    def xy_to_frenet(self, state:list):
        x, y, theta, beta = state


        self.s_curr, self.e_curr, psi_ref, x_spline, y_spline = self.utils.getClosest(x,y)

        self.curr_theta = theta

        self.heading_error = self.curr_theta - psi_ref
        
        state = np.array([self.s_curr, self.e_curr, self.heading_error, beta])

        return self.solve_MPC(state)
        # print("s_curr, e_curr, heading_error", s_curr, e_curr, heading_error)


    def solve_MPC(self, state):
        current_state = np.array(state)
        print("SIMU STATE = (in Frenet) ", current_state)
        control, estimated_state = self.acados_mpc.simulate(current_state)
        print("MPC OUTPUT = ", control)
        print("MPC ESTIMATED_STATE = (in Frenet)", estimated_state)
        return control, current_state



if __name__ == '__main__':
    print("MPC TEST Initialized")
    controller = MPC_Controller()
    tt02 = AckermannCar(L=0.257)

    state = [0.125,0.,0.,0.]

    s = []
    e = []
    v = []
    drate = []
    beta = []
    control, frenet_state = None, None

    i,j = 0,0
    while j != "q":
        i+=1
        print(f"STATE AT TIME {i/12.}s: (x,y,theta,beta) ", state)
        old_control, old_frenet_state = control, frenet_state
        control, frenet_state = controller.xy_to_frenet(state)
        if control is None:
            control, frenet_state = old_control, old_frenet_state
        s.append(frenet_state[0])
        e.append(frenet_state[1])
        v.append(control[0])
        drate.append(control[1])
        beta.append(state[3])


        state = tt02.kinematics(state, control)
        j = input("1 to stop \nd")
       
    import matplotlib.pyplot as plt

    plt.figure()
    plt.plot(s, label="s")
    plt.plot(e, label="e")
    plt.legend()
    plt.show()

    plt.figure()
    plt.plot(beta, label="beta")
    plt.plot(e, label="e")
    plt.legend()
    plt.show()