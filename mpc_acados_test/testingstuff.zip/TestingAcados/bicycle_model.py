from acados_template import AcadosOcp, AcadosOcpSolver, AcadosModel
import casadi as ca
import os
from pathlib import Path
import numpy as np


def getTrack(filename):
    track_file = os.path.join(str(Path(__file__).parent), filename)
    # array=np.loadtxt(track_file, delimiter=",")
    array= np.loadtxt(track_file)
    sref=array[:,0]
    xref=array[:,1]
    yref=array[:,2]
    psiref=array[:,3]
    kapparef=array[:,4]
    return sref,xref,yref,psiref, kapparef

def create_model(track="su_bigmap_splined.txt"):
    """
    Returns a simple kinematic bicycle model wrapped as an AcadosModel.
    States:  x, y, psi, v
    Inputs:  v (speed), deltarate)
    """
    [s0, _, _, _, kapparef] = getTrack(track)
    length = len(s0)
    pathlength = s0[-1]
    # copy loop to beginning and end
    s0 = np.append(s0, [s0[length - 1] + s0[1:length]])
    kapparef = np.append(kapparef, kapparef[1:length])
    s0 = np.append([-s0[length - 2] + s0[length - 81 : length - 2]], s0)
    kapparef = np.append(kapparef[length - 80 : length - 1], kapparef)

    # compute spline interpolations

    # WE HAVE A SET OF POINTS i.e. A DISCRETE MODEL OF Kappa(s), we want a continous function to have kappa for every s.
    kapparef_s = ca.interpolant("kapparef_s", "bspline", [s0], kapparef)

    # Define CasADi symbols
    s = ca.MX.sym("s") #arc length
    e = ca.MX.sym("e") #Lateral offset
    alpha = ca.MX.sym("alpha") #Heading error
    delta = ca.MX.sym("delta") #steering angle (idk the bounds yet)

    # theta_A = ca.MX.sym("theta_A") #estimation of progress (idk)

    x = ca.vertcat(s,e,alpha,delta)

    v = ca.MX.sym("v") #speed (in the frenet frame)
    steering_rate = ca.MX.sym("steering_rate") #Duty cycle (-1,1)

    u = ca.vertcat(v,steering_rate)

    s_dot = ca.MX.sym("s_dot") #arc length
    e_dot = ca.MX.sym("e_dot") #Lateral offset
    alpha_dot = ca.MX.sym("alpha_dot") #Heading error
    delta_dot = ca.MX.sym("delta_dot") #speed (in the frenet frame)
    # theta_A_dot = ca.MX.sym("theta_A_dot") #estimation of progress (idk)

    x_dot = ca.vertcat(s_dot, e_dot, alpha_dot, delta_dot)

    #Params

    L = 0.257/4.3 #TT02 wheelbase
    m = 2.331 #mass of car

    # Fxd = (Cm1 - Cm2 * v) * D - Cr2 * v * v - Cr0

    sdot = (v / (1 - e*kapparef_s(s))) * (ca.cos(alpha))
    f_expl = ca.vertcat(
        sdot,
        v * ca.sin(alpha),
        (v/L * delta) - kapparef_s(s) * sdot,
        steering_rate
    )

        # Build the AcadosModel
    model = AcadosModel()
    model.f_expl_expr = f_expl
    # For an explicit model: f_impl_expr = xdot - f_expl
    # either form is fine as long as it's consistent
    model.f_impl_expr = ca.vertcat(s_dot, e_dot, alpha_dot, delta_dot) - f_expl
    # model.f_impl_expr = ca.vertcat(s_dot, v_dot) - f_expl

    # model.params = params

    model.x = x
    model.u = u
    model.xdot = x_dot
    model.name = "kinematic_bicycle"

    constraint = ca.types.SimpleNamespace()

    constraint.delta_min = -0.4
    constraint.delta_max = 0.4

    constraint.steering_rate_min = -12
    constraint.steering_rate_max = 12 

    constraint.v_min = -5.0
    constraint.v_max = 5.0


    return model, constraint